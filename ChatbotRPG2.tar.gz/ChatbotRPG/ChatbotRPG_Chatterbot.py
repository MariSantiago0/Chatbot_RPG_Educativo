import os
import yaml
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

bot = ChatBot('Bot')
trainer = ListTrainer(bot)

trainer.train([
    "Olá, guerreiro.",
    "Saudações, viajante. Está pronto para sua missão?",
    "Sim!",
    "Sua missão é recuperar o cristal perdido nas cavernas de Eldor.",
    "Não.",
    "Então volte quando estiver preparado."
])

path = '/home/nana/Documents/ChatbotRPG/chatterbot-corpus-master/chatterbot_corpus/data/portuguese/'
lang_files = os.listdir(path)

for file in lang_files:
    with open(os.path.join(path, file), 'r', encoding='utf-8') as f:
        content = yaml.safe_load(f)
        for conversation in content['conversations']:
            trainer.train(conversation)

while True:
    ip = input('Converse com o Bot: ')
    if ip.strip().lower() == 'bye':
        print('Estou na espera para a próxima missão!')
        break
    reply = bot.get_response(ip)
    print('Cavaleiro -', reply)
